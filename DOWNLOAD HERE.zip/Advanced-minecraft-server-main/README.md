# Advanced-minecraft-server
Advanced minecraft server startup for windows 10/11
